import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('ngo_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(false);
  const [initializing, setInitializing] = useState(true);

  // Verify token on mount
  useEffect(() => {
    const token = localStorage.getItem('ngo_token');
    if (!token) { setInitializing(false); return; }
    authAPI.me()
      .then((res) => setUser(res.data.user))
      .catch(() => { localStorage.removeItem('ngo_token'); localStorage.removeItem('ngo_user'); })
      .finally(() => setInitializing(false));
  }, []);

  const login = useCallback(async (email, password) => {
    setLoading(true);
    try {
      const { data } = await authAPI.login(email, password);
      localStorage.setItem('ngo_token', data.token);
      localStorage.setItem('ngo_user', JSON.stringify(data.user));
      setUser(data.user);
      return { success: true };
    } catch (err) {
      const msg = err.response?.data?.message
        || Object.values(err.response?.data?.errors || {})[0]?.[0]
        || 'Login failed. Please try again.';
      return { success: false, message: msg };
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try { await authAPI.logout(); } catch (_) {}
    localStorage.removeItem('ngo_token');
    localStorage.removeItem('ngo_user');
    setUser(null);
  }, []);

  const isAdmin = user?.role?.slug === 'super-admin' || user?.role?.slug === 'hr-admin';
  const isSuperAdmin = user?.role?.slug === 'super-admin';

  return (
    <AuthContext.Provider value={{ user, loading, initializing, login, logout, isAdmin, isSuperAdmin }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
