// ── Spinner ───────────────────────────────────────────────────────────────────
export function Spinner({ size = 'md', className = '' }) {
  const sz = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-10 h-10' }[size];
  return (
    <span
      className={`inline-block ${sz} border-2 border-jade-500/30 border-t-jade-500 rounded-full animate-spin ${className}`}
    />
  );
}

// ── Loading Overlay ───────────────────────────────────────────────────────────
export function LoadingOverlay() {
  return (
    <div className="flex-1 flex items-center justify-center py-20">
      <Spinner size="lg" />
    </div>
  );
}

// ── Empty State ───────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="w-16 h-16 rounded-2xl bg-ink-700 flex items-center justify-center mb-4 text-slate-500 text-2xl">
        {icon}
      </div>
      <h3 className="font-display font-semibold text-slate-300 text-lg mb-1">{title}</h3>
      {description && <p className="text-slate-500 text-sm mb-4">{description}</p>}
      {action}
    </div>
  );
}

// ── Alert ─────────────────────────────────────────────────────────────────────
export function Alert({ type = 'error', message, onClose }) {
  if (!message) return null;
  const styles = {
    error: 'bg-rose-500/10 border-rose-500/30 text-rose-400',
    success: 'bg-jade-500/10 border-jade-500/30 text-jade-400',
    warning: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    info: 'bg-sky-500/10 border-sky-500/30 text-sky-400',
  };
  return (
    <div className={`flex items-start gap-3 px-4 py-3 rounded-xl border text-sm ${styles[type]}`}>
      <span className="flex-1">{message}</span>
      {onClose && (
        <button onClick={onClose} className="opacity-60 hover:opacity-100 transition-opacity text-lg leading-none">×</button>
      )}
    </div>
  );
}

// ── Modal ─────────────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, size = 'md' }) {
  if (!open) return null;
  const widths = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm" />
      <div className={`relative w-full ${widths[size]} card p-6 animate-slide-up max-h-[90vh] overflow-y-auto`}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display font-semibold text-slate-100 text-lg">{title}</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-ink-700 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400
                       flex items-center justify-center transition-all duration-200 text-xl leading-none"
          >
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ── Stat Card ─────────────────────────────────────────────────────────────────
export function StatCard({ icon, label, value, color = 'jade', trend }) {
  const colors = {
    jade: 'from-jade-500/20 to-jade-500/5 border-jade-500/20 text-jade-400',
    amber: 'from-amber-500/20 to-amber-500/5 border-amber-500/20 text-amber-400',
    rose: 'from-rose-500/20 to-rose-500/5 border-rose-500/20 text-rose-400',
    sky: 'from-sky-500/20 to-sky-500/5 border-sky-500/20 text-sky-400',
  };
  return (
    <div className={`card bg-gradient-to-br ${colors[color]} p-6 hover:shadow-card-hover transition-all duration-300 group`}>
      <div className="flex items-start justify-between mb-4">
        <div className={`w-11 h-11 rounded-xl bg-ink-800/80 flex items-center justify-center text-xl ${colors[color].split(' ')[3]}`}>
          {icon}
        </div>
        {trend && (
          <span className="text-xs font-mono text-slate-500">{trend}</span>
        )}
      </div>
      <div className="font-display font-bold text-3xl text-slate-100 mb-1">
        {value ?? <span className="opacity-30 text-2xl">—</span>}
      </div>
      <div className="text-sm font-body text-slate-400">{label}</div>
    </div>
  );
}

// ── Page Header ───────────────────────────────────────────────────────────────
export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
      <div>
        <h1 className="font-display font-bold text-2xl text-slate-100">{title}</h1>
        {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

// ── Confirm Dialog ────────────────────────────────────────────────────────────
export function ConfirmDialog({ open, onClose, onConfirm, title, message, loading }) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm">
      <p className="text-slate-400 text-sm mb-6">{message}</p>
      <div className="flex gap-3 justify-end">
        <button className="btn-ghost" onClick={onClose} disabled={loading}>Cancel</button>
        <button className="btn-danger" onClick={onConfirm} disabled={loading}>
          {loading ? <Spinner size="sm" /> : 'Confirm'}
        </button>
      </div>
    </Modal>
  );
}

// ── Pagination ────────────────────────────────────────────────────────────────
export function Pagination({ meta, onPage }) {
  if (!meta || meta.last_page <= 1) return null;
  const { current_page, last_page } = meta;
  const pages = [];
  for (let i = Math.max(1, current_page - 2); i <= Math.min(last_page, current_page + 2); i++) {
    pages.push(i);
  }
  return (
    <div className="flex items-center justify-between pt-4 border-t border-ink-700">
      <p className="text-xs text-slate-500">
        Page {current_page} of {last_page} · {meta.total} records
      </p>
      <div className="flex gap-1">
        <button
          className="btn-ghost px-3 py-1.5 text-xs"
          onClick={() => onPage(current_page - 1)}
          disabled={current_page === 1}
        >←</button>
        {pages.map((p) => (
          <button
            key={p}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              p === current_page
                ? 'bg-jade-500 text-white'
                : 'bg-ink-700 text-slate-400 hover:text-jade-400'
            }`}
            onClick={() => onPage(p)}
          >{p}</button>
        ))}
        <button
          className="btn-ghost px-3 py-1.5 text-xs"
          onClick={() => onPage(current_page + 1)}
          disabled={current_page === last_page}
        >→</button>
      </div>
    </div>
  );
}
