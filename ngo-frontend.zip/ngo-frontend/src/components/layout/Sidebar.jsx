import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const ICON = {
  dashboard: '▦',
  employees: '👥',
  offices: '🏢',
  attendance: '📋',
  leaves: '🌿',
  reports: '📊',
  settings: '⚙️',
  logout: '↪',
};

export default function Sidebar({ open, onClose }) {
  const { user, logout, isAdmin, isSuperAdmin } = useAuth();
  const navigate = useNavigate();

  const links = [
    { to: '/dashboard', label: 'Dashboard', icon: ICON.dashboard, always: true },
    { to: '/employees', label: 'Employees', icon: ICON.employees, admin: true },
    { to: '/offices', label: 'Offices', icon: ICON.offices, always: true },
    { to: '/attendance', label: 'Attendance', icon: ICON.attendance, always: true },
    { to: '/leaves', label: 'Leaves', icon: ICON.leaves, always: true },
  ];

  const visibleLinks = links.filter((l) => l.always || (l.admin && isAdmin));

  async function handleLogout() {
    await logout();
    navigate('/login');
  }

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-ink-950/70 backdrop-blur-sm z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`
          fixed top-0 left-0 h-full w-64 z-40
          bg-ink-900 border-r border-ink-600
          flex flex-col
          transition-transform duration-300 ease-in-out
          ${open ? 'translate-x-0' : '-translate-x-full'}
          lg:translate-x-0 lg:static lg:z-auto
        `}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-ink-700">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-jade-500 to-jade-600 flex items-center justify-center shadow-glow-sm">
            <span className="font-display font-bold text-white text-sm">N</span>
          </div>
          <div>
            <div className="font-display font-bold text-slate-100 text-sm leading-tight">NGO System</div>
            <div className="text-xs text-slate-500 font-body">Management</div>
          </div>
          <button
            onClick={onClose}
            className="ml-auto lg:hidden text-slate-500 hover:text-slate-300 transition-colors"
          >✕</button>
        </div>

        {/* User info */}
        <div className="px-4 py-4 border-b border-ink-700">
          <div className="flex items-center gap-3 px-2 py-2 rounded-xl bg-ink-800/60">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-jade-500/40 to-sky-500/40 flex items-center justify-center">
              <span className="font-display font-semibold text-jade-400 text-sm">
                {user?.name?.charAt(0)?.toUpperCase() || '?'}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-body font-medium text-slate-200 text-sm truncate">{user?.name}</div>
              <div className="text-xs text-slate-500 truncate">{user?.role?.name}</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <p className="px-3 mb-2 text-xs font-display font-semibold uppercase tracking-widest text-slate-600">
            Navigation
          </p>
          {visibleLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={onClose}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            >
              <span className="text-base leading-none">{link.icon}</span>
              <span>{link.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Logout */}
        <div className="px-3 pb-5 pt-2 border-t border-ink-700">
          <button
            onClick={handleLogout}
            className="sidebar-link w-full hover:text-rose-400 hover:bg-rose-500/10"
          >
            <span className="text-base leading-none">{ICON.logout}</span>
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
