import React from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const TITLES = {
  '/dashboard': 'Dashboard',
  '/employees': 'Employees',
  '/offices': 'Offices',
  '/attendance': 'Attendance',
  '/leaves': 'Leave Management',
};

export default function Topbar({ onMenuToggle }) {
  const { pathname } = useLocation();
  const { user } = useAuth();
  const title = TITLES[pathname] || 'NGO System';
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });

  return (
    <header className="h-16 bg-ink-900/80 border-b border-ink-700 backdrop-blur-md flex items-center px-6 gap-4 sticky top-0 z-20">
      <button
        onClick={onMenuToggle}
        className="lg:hidden w-9 h-9 rounded-lg bg-ink-800 hover:bg-ink-700 text-slate-400 hover:text-jade-400
                   flex items-center justify-center transition-all duration-200"
        aria-label="Toggle menu"
      >
        <span className="text-lg leading-none">☰</span>
      </button>

      <div className="flex-1">
        <h2 className="font-display font-semibold text-slate-200 text-base">{title}</h2>
        <p className="text-xs text-slate-500 font-body hidden sm:block">{dateStr}</p>
      </div>

      {/* Status indicator */}
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-jade-500/10 border border-jade-500/20">
        <span className="w-1.5 h-1.5 rounded-full bg-jade-400 animate-pulse2" />
        <span className="text-xs font-body font-medium text-jade-400 hidden sm:inline">Online</span>
      </div>

      {/* Avatar */}
      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-jade-500/40 to-sky-500/40 flex items-center justify-center border border-jade-500/20">
        <span className="font-display font-semibold text-jade-400 text-sm">
          {user?.name?.charAt(0)?.toUpperCase() || '?'}
        </span>
      </div>
    </header>
  );
}
