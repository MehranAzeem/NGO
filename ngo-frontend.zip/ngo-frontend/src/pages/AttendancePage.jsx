import React, { useEffect, useState, useCallback } from 'react';
import { attendanceAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { PageHeader, LoadingOverlay, EmptyState, Alert, Pagination, Spinner, Modal } from '../components/ui';

function statusBadge(status) {
  const map = { present: 'badge-green', late: 'badge-yellow', 'half-day': 'badge-blue', pending: 'badge-gray', absent: 'badge-red' };
  return <span className={map[status] || 'badge-gray'}>{status}</span>;
}

function fmt(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function fmtDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function AttendancePage() {
  const { user } = useAuth();
  const [records, setRecords] = useState([]);
  const [meta, setMeta] = useState(null);
  const [todayRecord, setTodayRecord] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState({ date_from: '', date_to: '', status: '' });

  // Check-in/out modal
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [checkType, setCheckType] = useState('in'); // 'in' | 'out'
  const [coords, setCoords] = useState({ latitude: '', longitude: '' });
  const [locating, setLocating] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const fetchRecords = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) };
      const r = await attendanceAPI.list(params);
      setRecords(r.data.data || r.data);
      setMeta(r.data.meta || null);
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to load attendance.');
    } finally {
      setLoading(false);
    }
  }, [page, filters]);

  useEffect(() => { fetchRecords(); }, [fetchRecords]);

  useEffect(() => {
    attendanceAPI.today()
      .then((r) => setTodayRecord(r.data.attendance))
      .catch(() => {});
  }, []);

  function openCheckModal(type) {
    setCheckType(type);
    setCoords({ latitude: '', longitude: '' });
    setShowCheckIn(true);
    setLocating(true);
    navigator.geolocation?.getCurrentPosition(
      (pos) => {
        setCoords({ latitude: pos.coords.latitude.toFixed(7), longitude: pos.coords.longitude.toFixed(7) });
        setLocating(false);
      },
      () => { setLocating(false); },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  async function handleCheckSubmit() {
    if (!coords.latitude || !coords.longitude) {
      setError('Location is required. Please allow location access or enter coordinates manually.');
      return;
    }
    setSubmitting(true);
    try {
      const payload = { latitude: parseFloat(coords.latitude), longitude: parseFloat(coords.longitude) };
      if (checkType === 'in') {
        const r = await attendanceAPI.checkIn(payload);
        setTodayRecord(r.data.attendance);
        setSuccess(r.data.message);
      } else {
        const r = await attendanceAPI.checkOut(payload);
        setTodayRecord(r.data.attendance);
        setSuccess(r.data.message);
      }
      setShowCheckIn(false);
      fetchRecords();
    } catch (e) {
      setError(e.response?.data?.message || 'Check-in/out failed.');
      setShowCheckIn(false);
    } finally {
      setSubmitting(false);
    }
  }

  const canCheckIn = !todayRecord || !todayRecord.checked_in_at;
  const canCheckOut = todayRecord?.checked_in_at && !todayRecord?.checked_out_at;

  return (
    <div className="space-y-6">
      <PageHeader title="Attendance" subtitle="Track daily attendance and working hours" />

      {error && <Alert type="error" message={error} onClose={() => setError('')} />}
      {success && <Alert type="success" message={success} onClose={() => setSuccess('')} />}

      {/* Today's status card */}
      <div className="card p-6">
        <h3 className="font-display font-semibold text-slate-200 mb-4 flex items-center gap-2">
          <span>📅</span> Today's Status
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-5">
          <div className="bg-ink-900/60 rounded-xl p-4">
            <div className="text-xs text-slate-500 mb-1 font-display font-semibold uppercase tracking-widest">Check In</div>
            <div className="text-2xl font-display font-bold text-jade-400">
              {todayRecord?.checked_in_at ? fmt(todayRecord.checked_in_at) : '—'}
            </div>
          </div>
          <div className="bg-ink-900/60 rounded-xl p-4">
            <div className="text-xs text-slate-500 mb-1 font-display font-semibold uppercase tracking-widest">Check Out</div>
            <div className="text-2xl font-display font-bold text-sky-400">
              {todayRecord?.checked_out_at ? fmt(todayRecord.checked_out_at) : '—'}
            </div>
          </div>
          <div className="bg-ink-900/60 rounded-xl p-4">
            <div className="text-xs text-slate-500 mb-1 font-display font-semibold uppercase tracking-widest">Hours</div>
            <div className="text-2xl font-display font-bold text-amber-400">
              {todayRecord?.working_hours ?? '—'}
            </div>
          </div>
        </div>
        <div className="flex gap-3 flex-wrap">
          <button
            className="btn-primary"
            onClick={() => openCheckModal('in')}
            disabled={!canCheckIn}
          >
            {canCheckIn ? '✓ Check In' : 'Already Checked In'}
          </button>
          <button
            className="btn-ghost"
            onClick={() => openCheckModal('out')}
            disabled={!canCheckOut}
          >
            {canCheckOut ? '↩ Check Out' : todayRecord?.checked_out_at ? 'Already Checked Out' : 'Check Out'}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <input
          type="date"
          className="input-field w-44"
          value={filters.date_from}
          onChange={(e) => setFilters((p) => ({ ...p, date_from: e.target.value }))}
          placeholder="From date"
        />
        <input
          type="date"
          className="input-field w-44"
          value={filters.date_to}
          onChange={(e) => setFilters((p) => ({ ...p, date_to: e.target.value }))}
        />
        <select
          className="select-field w-40"
          value={filters.status}
          onChange={(e) => setFilters((p) => ({ ...p, status: e.target.value }))}
        >
          <option value="">All Statuses</option>
          <option value="present">Present</option>
          <option value="late">Late</option>
          <option value="half-day">Half Day</option>
          <option value="pending">Pending</option>
        </select>
        <button className="btn-ghost" onClick={() => setFilters({ date_from: '', date_to: '', status: '' })}>
          Clear
        </button>
      </div>

      {/* Attendance log table */}
      <div className="card overflow-hidden">
        {loading ? (
          <LoadingOverlay />
        ) : records.length === 0 ? (
          <EmptyState icon="📋" title="No records found" description="No attendance records match the current filters." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-ink-900/60 border-b border-ink-700">
                <tr>
                  {['Employee', 'Date', 'Check In', 'Check Out', 'Hours', 'Status', 'Office'].map((h) => (
                    <th key={h} className="table-header text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {records.map((rec) => (
                  <tr key={rec.id} className="table-row">
                    <td className="table-cell">{rec.employee?.name || 'Me'}</td>
                    <td className="table-cell">{fmtDate(rec.checked_in_at)}</td>
                    <td className="table-cell font-mono text-jade-400">{fmt(rec.checked_in_at)}</td>
                    <td className="table-cell font-mono text-sky-400">{fmt(rec.checked_out_at)}</td>
                    <td className="table-cell font-mono text-amber-400">{rec.working_hours ?? '—'}</td>
                    <td className="table-cell">{statusBadge(rec.status)}</td>
                    <td className="table-cell text-slate-500">{rec.office?.name || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="px-4 py-3">
              <Pagination meta={meta} onPage={setPage} />
            </div>
          </div>
        )}
      </div>

      {/* Check-in / Check-out Modal */}
      <Modal
        open={showCheckIn}
        onClose={() => setShowCheckIn(false)}
        title={checkType === 'in' ? 'Check In' : 'Check Out'}
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-slate-400 text-sm">
            {locating ? 'Getting your location…' : 'Your GPS location has been captured.'}
          </p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1 font-display font-semibold uppercase tracking-widest">Latitude</label>
              <input
                className="input-field"
                value={coords.latitude}
                onChange={(e) => setCoords((p) => ({ ...p, latitude: e.target.value }))}
                placeholder="24.8607"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1 font-display font-semibold uppercase tracking-widest">Longitude</label>
              <input
                className="input-field"
                value={coords.longitude}
                onChange={(e) => setCoords((p) => ({ ...p, longitude: e.target.value }))}
                placeholder="67.0011"
              />
            </div>
          </div>
          {locating && (
            <div className="flex items-center gap-2 text-jade-400 text-sm">
              <Spinner size="sm" /> Locating…
            </div>
          )}
        </div>
        <div className="flex gap-3 justify-end mt-6">
          <button className="btn-ghost" onClick={() => setShowCheckIn(false)}>Cancel</button>
          <button className="btn-primary" onClick={handleCheckSubmit} disabled={submitting || locating}>
            {submitting ? <Spinner size="sm" /> : checkType === 'in' ? 'Confirm Check In' : 'Confirm Check Out'}
          </button>
        </div>
      </Modal>
    </div>
  );
}
