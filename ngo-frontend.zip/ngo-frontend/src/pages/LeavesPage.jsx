import React, { useEffect, useState, useCallback } from 'react';
import { leaveAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import {
  PageHeader, LoadingOverlay, EmptyState, Alert,
  Modal, ConfirmDialog, Pagination, Spinner
} from '../components/ui';

const TYPE_OPTS = ['annual', 'sick', 'casual', 'emergency', 'unpaid'];

function statusBadge(s) {
  const map = { pending: 'badge-yellow', approved: 'badge-green', rejected: 'badge-red', cancelled: 'badge-gray' };
  return <span className={map[s] || 'badge-gray'}>{s}</span>;
}

function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function LeavesPage() {
  const { isAdmin } = useAuth();
  const [leaves, setLeaves] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [page, setPage] = useState(1);
  const [filterStatus, setFilterStatus] = useState('');

  // Apply leave modal
  const [showApply, setShowApply] = useState(false);
  const [applyForm, setApplyForm] = useState({ type: 'annual', start_date: '', end_date: '', reason: '' });
  const [applyError, setApplyError] = useState('');
  const [applying, setApplying] = useState(false);

  // Reject modal
  const [rejectTarget, setRejectTarget] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejecting, setRejecting] = useState(false);

  // Cancel confirm
  const [cancelTarget, setCancelTarget] = useState(null);
  const [cancelling, setCancelling] = useState(false);

  const fetchLeaves = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, ...(filterStatus ? { status: filterStatus } : {}) };
      const r = await leaveAPI.list(params);
      setLeaves(r.data.data || r.data);
      setMeta(r.data.meta || null);
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to load leaves.');
    } finally {
      setLoading(false);
    }
  }, [page, filterStatus]);

  useEffect(() => { fetchLeaves(); }, [fetchLeaves]);

  async function handleApply() {
    setApplying(true);
    setApplyError('');
    try {
      await leaveAPI.apply(applyForm);
      setSuccess('Leave application submitted.');
      setShowApply(false);
      fetchLeaves();
    } catch (e) {
      const errs = e.response?.data?.errors;
      setApplyError(errs ? Object.values(errs).flat().join(' ') : e.response?.data?.message || 'Failed to apply.');
    } finally {
      setApplying(false);
    }
  }

  async function handleApprove(leave) {
    try {
      await leaveAPI.approve(leave.id);
      setSuccess('Leave approved.');
      fetchLeaves();
    } catch (e) {
      setError(e.response?.data?.message || 'Approval failed.');
    }
  }

  async function handleReject() {
    setRejecting(true);
    try {
      await leaveAPI.reject(rejectTarget.id, rejectReason);
      setSuccess('Leave rejected.');
      setRejectTarget(null);
      fetchLeaves();
    } catch (e) {
      setError(e.response?.data?.message || 'Rejection failed.');
      setRejectTarget(null);
    } finally {
      setRejecting(false);
    }
  }

  async function handleCancel() {
    setCancelling(true);
    try {
      await leaveAPI.cancel(cancelTarget.id);
      setSuccess('Leave cancelled.');
      setCancelTarget(null);
      fetchLeaves();
    } catch (e) {
      setError(e.response?.data?.message || 'Cancel failed.');
      setCancelTarget(null);
    } finally {
      setCancelling(false);
    }
  }

  const AF = (field) => ({
    value: applyForm[field],
    onChange: (e) => setApplyForm((p) => ({ ...p, [field]: e.target.value })),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Leaves"
        subtitle="Apply and manage leave requests"
        action={
          <button className="btn-primary" onClick={() => { setApplyForm({ type: 'annual', start_date: '', end_date: '', reason: '' }); setApplyError(''); setShowApply(true); }}>
            + Apply Leave
          </button>
        }
      />

      {error && <Alert type="error" message={error} onClose={() => setError('')} />}
      {success && <Alert type="success" message={success} onClose={() => setSuccess('')} />}

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <select
          className="select-field w-44"
          value={filterStatus}
          onChange={(e) => { setFilterStatus(e.target.value); setPage(1); }}
        >
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <LoadingOverlay />
        ) : leaves.length === 0 ? (
          <EmptyState
            icon="🌿"
            title="No leave records"
            description="No leave applications found."
            action={<button className="btn-primary" onClick={() => setShowApply(true)}>Apply Now</button>}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-ink-900/60 border-b border-ink-700">
                <tr>
                  {['Employee', 'Type', 'From', 'To', 'Days', 'Reason', 'Status', 'Actions'].map((h) => (
                    <th key={h} className="table-header text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {leaves.map((leave) => (
                  <tr key={leave.id} className="table-row">
                    <td className="table-cell">
                      <div className="font-medium text-slate-200">{leave.employee?.user?.name || leave.employee?.name || 'Me'}</div>
                    </td>
                    <td className="table-cell capitalize">
                      <span className="badge-blue">{leave.type}</span>
                    </td>
                    <td className="table-cell">{fmtDate(leave.start_date)}</td>
                    <td className="table-cell">{fmtDate(leave.end_date)}</td>
                    <td className="table-cell">
                      <span className="font-mono font-semibold text-amber-400">{leave.total_days}d</span>
                    </td>
                    <td className="table-cell max-w-[180px]">
                      <p className="truncate text-slate-400 text-sm">{leave.reason}</p>
                    </td>
                    <td className="table-cell">{statusBadge(leave.status)}</td>
                    <td className="table-cell">
                      <div className="flex gap-1.5 flex-wrap">
                        {isAdmin && leave.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleApprove(leave)}
                              className="px-2.5 py-1 rounded-lg bg-jade-500/15 hover:bg-jade-500/30 text-jade-400 text-xs font-medium transition-all"
                            >Approve</button>
                            <button
                              onClick={() => { setRejectTarget(leave); setRejectReason(''); }}
                              className="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-400 text-xs font-medium transition-all"
                            >Reject</button>
                          </>
                        )}
                        {leave.status === 'pending' && (
                          <button
                            onClick={() => setCancelTarget(leave)}
                            className="px-2.5 py-1 rounded-lg bg-ink-700 hover:bg-ink-600 text-slate-400 text-xs font-medium transition-all"
                          >Cancel</button>
                        )}
                        {leave.rejection_reason && (
                          <span className="text-xs text-slate-500 italic">{leave.rejection_reason.substring(0, 30)}…</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="px-4 py-3">
              <Pagination meta={meta} onPage={setPage} />
            </div>
          </div>
        )}
      </div>

      {/* Apply Modal */}
      <Modal open={showApply} onClose={() => setShowApply(false)} title="Apply for Leave" size="md">
        {applyError && <Alert type="error" message={applyError} className="mb-4" />}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">Leave Type</label>
            <select className="select-field" {...AF('type')}>
              {TYPE_OPTS.map((t) => <option key={t} value={t} className="capitalize">{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">Start Date <span className="text-rose-400">*</span></label>
              <input type="date" className="input-field" {...AF('start_date')} />
            </div>
            <div>
              <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">End Date <span className="text-rose-400">*</span></label>
              <input type="date" className="input-field" {...AF('end_date')} />
            </div>
          </div>
          <div>
            <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">Reason <span className="text-rose-400">*</span></label>
            <textarea
              className="input-field resize-none h-24"
              placeholder="Briefly describe the reason for this leave…"
              {...AF('reason')}
            />
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-6">
          <button className="btn-ghost" onClick={() => setShowApply(false)} disabled={applying}>Cancel</button>
          <button className="btn-primary" onClick={handleApply} disabled={applying}>
            {applying ? <Spinner size="sm" /> : 'Submit Application'}
          </button>
        </div>
      </Modal>

      {/* Reject Modal */}
      <Modal open={!!rejectTarget} onClose={() => setRejectTarget(null)} title="Reject Leave" size="sm">
        <div className="space-y-4">
          <p className="text-slate-400 text-sm">
            Rejecting leave for <strong className="text-slate-200">{rejectTarget?.employee?.user?.name}</strong>.
          </p>
          <div>
            <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">Rejection Reason</label>
            <textarea
              className="input-field resize-none h-20"
              placeholder="Provide a reason…"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
            />
          </div>
        </div>
        <div className="flex gap-3 justify-end mt-6">
          <button className="btn-ghost" onClick={() => setRejectTarget(null)} disabled={rejecting}>Cancel</button>
          <button className="btn-danger" onClick={handleReject} disabled={rejecting}>
            {rejecting ? <Spinner size="sm" /> : 'Reject Leave'}
          </button>
        </div>
      </Modal>

      {/* Cancel confirm */}
      <ConfirmDialog
        open={!!cancelTarget}
        onClose={() => setCancelTarget(null)}
        onConfirm={handleCancel}
        loading={cancelling}
        title="Cancel Leave"
        message="Are you sure you want to cancel this leave application?"
      />
    </div>
  );
}
