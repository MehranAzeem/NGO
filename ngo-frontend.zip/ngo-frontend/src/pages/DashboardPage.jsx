import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { dashboardAPI } from '../services/api';
import { StatCard, LoadingOverlay, Alert } from '../components/ui';

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    dashboardAPI.index()
      .then((r) => setStats(r.data))
      .catch((e) => {
        // Dashboard endpoint may not be fully implemented yet; show friendly error
        setError(e.response?.data?.message || 'Could not load dashboard data. Backend may still be setting up.');
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingOverlay />;

  return (
    <div className="space-y-8">
      {/* Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display font-bold text-2xl text-slate-100">
            Good {getGreeting()}, <span className="text-jade-400">{user?.name?.split(' ')[0]}</span> 👋
          </h1>
          <p className="text-slate-500 text-sm mt-0.5 font-body">
            Here's what's happening today at your organisation.
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-ink-800 border border-ink-600">
          <span className="w-2 h-2 rounded-full bg-jade-400 animate-pulse2" />
          <span className="text-xs font-body text-slate-400">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
        </div>
      </div>

      {error && <Alert type="warning" message={error} onClose={() => setError('')} />}

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        <StatCard
          icon="👥"
          label="Total Employees"
          value={stats?.total_employees ?? stats?.employees_count ?? '—'}
          color="jade"
        />
        <StatCard
          icon="📋"
          label="Attendance Today"
          value={stats?.attendance_today ?? stats?.checked_in_today ?? '—'}
          color="sky"
        />
        <StatCard
          icon="🏢"
          label="Total Offices"
          value={stats?.total_offices ?? stats?.offices_count ?? '—'}
          color="amber"
        />
        <StatCard
          icon="🌿"
          label="Pending Leaves"
          value={stats?.pending_leaves ?? stats?.leaves_pending ?? '—'}
          color="rose"
        />
      </div>

      {/* Quick info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Role info card */}
        <div className="card p-6">
          <h3 className="font-display font-semibold text-slate-200 mb-4 flex items-center gap-2">
            <span>🔐</span> Your Access
          </h3>
          <div className="space-y-3">
            <InfoRow label="Role" value={user?.role?.name} />
            <InfoRow label="Email" value={user?.email} />
            {user?.employee && (
              <>
                <InfoRow label="Department" value={user.employee.department} />
                <InfoRow label="Designation" value={user.employee.designation} />
                {user.employee.office && (
                  <InfoRow label="Office" value={user.employee.office.name} />
                )}
              </>
            )}
          </div>
        </div>

        {/* Quick actions */}
        <div className="card p-6">
          <h3 className="font-display font-semibold text-slate-200 mb-4 flex items-center gap-2">
            <span>⚡</span> Quick Actions
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { href: '/attendance', icon: '📋', label: 'Mark Attendance' },
              { href: '/leaves', icon: '🌿', label: 'Apply Leave' },
              { href: '/employees', icon: '👥', label: 'View Employees' },
              { href: '/offices', icon: '🏢', label: 'View Offices' },
            ].map((a) => (
              <a
                key={a.href}
                href={a.href}
                className="flex items-center gap-3 px-4 py-3 rounded-xl bg-ink-800 border border-ink-600
                           hover:border-jade-500/40 hover:bg-ink-700 transition-all duration-200 group"
              >
                <span className="text-xl">{a.icon}</span>
                <span className="text-sm font-body text-slate-300 group-hover:text-jade-400 transition-colors">
                  {a.label}
                </span>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs font-display font-semibold uppercase tracking-widest text-slate-500">{label}</span>
      <span className="text-sm font-body text-slate-300">{value || '—'}</span>
    </div>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 18) return 'afternoon';
  return 'evening';
}
