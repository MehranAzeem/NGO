import React, { useEffect, useState, useCallback } from 'react';
import { officeAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import {
  PageHeader, LoadingOverlay, EmptyState, Alert,
  Modal, ConfirmDialog, Spinner
} from '../components/ui';

const EMPTY = { name: '', address: '', latitude: '', longitude: '', allowed_radius_m: 100, status: 'active' };

export default function OfficesPage() {
  const { isSuperAdmin } = useAuth();
  const [offices, setOffices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [formData, setFormData] = useState(EMPTY);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const fetch = useCallback(() => {
    setLoading(true);
    officeAPI.list()
      .then((r) => setOffices(r.data.data || r.data))
      .catch((e) => setError(e.response?.data?.message || 'Failed to load offices.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  function openCreate() {
    setFormData(EMPTY);
    setEditTarget(null);
    setFormError('');
    setShowForm(true);
  }

  function openEdit(office) {
    setFormData({
      name: office.name,
      address: office.address || '',
      latitude: office.latitude,
      longitude: office.longitude,
      allowed_radius_m: office.allowed_radius_m || 100,
      status: office.status,
    });
    setEditTarget(office);
    setFormError('');
    setShowForm(true);
  }

  async function handleSave() {
    setSaving(true);
    setFormError('');
    try {
      if (editTarget) await officeAPI.update(editTarget.id, formData);
      else await officeAPI.create(formData);
      setSuccess(editTarget ? 'Office updated.' : 'Office created.');
      setShowForm(false);
      fetch();
    } catch (e) {
      const errs = e.response?.data?.errors;
      setFormError(errs ? Object.values(errs).flat().join(' ') : e.response?.data?.message || 'Save failed.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    setDeleting(true);
    try {
      await officeAPI.delete(deleteTarget.id);
      setSuccess('Office deleted.');
      setDeleteTarget(null);
      fetch();
    } catch (e) {
      setError(e.response?.data?.message || 'Delete failed.');
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  }

  const F = (field) => ({
    value: formData[field],
    onChange: (e) => setFormData((p) => ({ ...p, [field]: e.target.value })),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Offices"
        subtitle="Manage office locations and geo-fencing"
        action={
          isSuperAdmin && (
            <button className="btn-primary" onClick={openCreate}>+ Add Office</button>
          )
        }
      />

      {error && <Alert type="error" message={error} onClose={() => setError('')} />}
      {success && <Alert type="success" message={success} onClose={() => setSuccess('')} />}

      {loading ? (
        <LoadingOverlay />
      ) : offices.length === 0 ? (
        <EmptyState
          icon="🏢"
          title="No offices yet"
          description="Create your first office to start managing attendance."
          action={isSuperAdmin && <button className="btn-primary" onClick={openCreate}>Add Office</button>}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {offices.map((office) => (
            <div key={office.id} className="card p-5 hover:shadow-card-hover transition-all duration-300 group">
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400 text-xl">
                  🏢
                </div>
                <span className={office.status === 'active' ? 'badge-green' : 'badge-gray'}>
                  {office.status}
                </span>
              </div>
              <h3 className="font-display font-semibold text-slate-200 mb-1">{office.name}</h3>
              <p className="text-sm text-slate-500 mb-4 line-clamp-2">{office.address || 'No address set'}</p>
              <div className="space-y-2 border-t border-ink-700 pt-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Coordinates</span>
                  <span className="font-mono text-slate-400">{office.latitude}, {office.longitude}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Geo-fence Radius</span>
                  <span className="font-mono text-jade-400">{office.allowed_radius_m}m</span>
                </div>
              </div>
              {isSuperAdmin && (
                <div className="flex gap-2 mt-4 pt-4 border-t border-ink-700">
                  <button
                    onClick={() => openEdit(office)}
                    className="flex-1 py-2 rounded-lg bg-ink-700 hover:bg-sky-500/20 text-slate-400 hover:text-sky-400 text-xs font-medium transition-all"
                  >Edit</button>
                  <button
                    onClick={() => setDeleteTarget(office)}
                    className="flex-1 py-2 rounded-lg bg-ink-700 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 text-xs font-medium transition-all"
                  >Delete</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Form Modal */}
      <Modal open={showForm} onClose={() => setShowForm(false)} title={editTarget ? 'Edit Office' : 'Add Office'}>
        {formError && <Alert type="error" message={formError} className="mb-4" />}
        <div className="space-y-4">
          <FormField label="Office Name" required>
            <input className="input-field" placeholder="Head Office" {...F('name')} />
          </FormField>
          <FormField label="Address">
            <input className="input-field" placeholder="123 Street, City" {...F('address')} />
          </FormField>
          <div className="grid grid-cols-2 gap-4">
            <FormField label="Latitude" required>
              <input type="number" step="any" className="input-field" placeholder="24.8607" {...F('latitude')} />
            </FormField>
            <FormField label="Longitude" required>
              <input type="number" step="any" className="input-field" placeholder="67.0011" {...F('longitude')} />
            </FormField>
          </div>
          <FormField label="Geo-fence Radius (metres)">
            <input type="number" className="input-field" placeholder="100" {...F('allowed_radius_m')} />
          </FormField>
          <FormField label="Status">
            <select className="select-field" {...F('status')}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </FormField>
        </div>
        <div className="flex gap-3 justify-end mt-6">
          <button className="btn-ghost" onClick={() => setShowForm(false)} disabled={saving}>Cancel</button>
          <button className="btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? <Spinner size="sm" /> : editTarget ? 'Save Changes' : 'Create Office'}
          </button>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Office"
        message={`Delete "${deleteTarget?.name}"? Employees assigned here may be affected.`}
      />
    </div>
  );
}

function FormField({ label, required, children }) {
  return (
    <div>
      <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">
        {label}{required && <span className="text-rose-400 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  );
}
