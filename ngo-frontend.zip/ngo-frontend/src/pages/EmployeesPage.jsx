import React, { useEffect, useState, useCallback } from 'react';
import { employeeAPI, officeAPI } from '../services/api';
import {
  PageHeader, LoadingOverlay, EmptyState, Alert,
  Modal, ConfirmDialog, Pagination, Spinner
} from '../components/ui';

const EMPTY_FORM = {
  name: '', email: '', password: '', phone: '', cnic: '',
  designation: '', department: '', employment_type: 'full-time',
  office_id: '', date_of_joining: '', emergency_contact_name: '',
  emergency_contact_phone: '',
};

export default function EmployeesPage() {
  const [employees, setEmployees] = useState([]);
  const [meta, setMeta] = useState(null);
  const [offices, setOffices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  // Modal states
  const [showForm, setShowForm] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [formData, setFormData] = useState(EMPTY_FORM);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const fetchEmployees = useCallback(async () => {
    setLoading(true);
    try {
      const r = await employeeAPI.list({ page, search: search || undefined });
      setEmployees(r.data.data || r.data);
      setMeta(r.data.meta || null);
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to load employees.');
    } finally {
      setLoading(false);
    }
  }, [page, search]);

  useEffect(() => { fetchEmployees(); }, [fetchEmployees]);

  useEffect(() => {
    officeAPI.list().then((r) => setOffices(r.data.data || r.data)).catch(() => {});
  }, []);

  function openCreate() {
    setFormData(EMPTY_FORM);
    setEditTarget(null);
    setFormError('');
    setShowForm(true);
  }

  function openEdit(emp) {
    setFormData({
      name: emp.user?.name || emp.name || '',
      email: emp.user?.email || emp.email || '',
      password: '',
      phone: emp.phone || '',
      cnic: emp.cnic || '',
      designation: emp.designation || '',
      department: emp.department || '',
      employment_type: emp.employment_type || 'full-time',
      office_id: emp.office_id || emp.office?.id || '',
      date_of_joining: emp.date_of_joining || '',
      emergency_contact_name: emp.emergency_contact_name || '',
      emergency_contact_phone: emp.emergency_contact_phone || '',
    });
    setEditTarget(emp);
    setFormError('');
    setShowForm(true);
  }

  async function handleSave() {
    setSaving(true);
    setFormError('');
    try {
      const payload = { ...formData };
      if (editTarget && !payload.password) delete payload.password;
      if (editTarget) await employeeAPI.update(editTarget.id, payload);
      else await employeeAPI.create(payload);
      setSuccess(editTarget ? 'Employee updated.' : 'Employee created.');
      setShowForm(false);
      fetchEmployees();
    } catch (e) {
      const errs = e.response?.data?.errors;
      const msg = errs
        ? Object.values(errs).flat().join(' ')
        : e.response?.data?.message || 'Save failed.';
      setFormError(msg);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    setDeleting(true);
    try {
      await employeeAPI.delete(deleteTarget.id);
      setSuccess('Employee deleted.');
      setDeleteTarget(null);
      fetchEmployees();
    } catch (e) {
      setError(e.response?.data?.message || 'Delete failed.');
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  }

  const F = (field) => ({
    value: formData[field],
    onChange: (e) => setFormData((p) => ({ ...p, [field]: e.target.value })),
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Employees"
        subtitle="Manage your organisation's workforce"
        action={
          <button className="btn-primary" onClick={openCreate}>
            + Add Employee
          </button>
        }
      />

      {error && <Alert type="error" message={error} onClose={() => setError('')} />}
      {success && <Alert type="success" message={success} onClose={() => setSuccess('')} />}

      {/* Search */}
      <div className="flex gap-3">
        <input
          className="input-field max-w-sm"
          placeholder="Search employees…"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
        />
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <LoadingOverlay />
        ) : employees.length === 0 ? (
          <EmptyState
            icon="👥"
            title="No employees found"
            description="Add your first employee to get started."
            action={<button className="btn-primary" onClick={openCreate}>Add Employee</button>}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-ink-900/60 border-b border-ink-700">
                <tr>
                  {['Name', 'CNIC', 'Designation', 'Department', 'Office', 'Type', 'Actions'].map((h) => (
                    <th key={h} className="table-header text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {employees.map((emp) => (
                  <tr key={emp.id} className="table-row">
                    <td className="table-cell">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-jade-500/30 to-sky-500/30
                                        flex items-center justify-center text-jade-400 font-display font-semibold text-xs">
                          {(emp.user?.name || emp.name || '?').charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-medium text-slate-200">{emp.user?.name || emp.name}</div>
                          <div className="text-xs text-slate-500">{emp.user?.email || emp.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="table-cell font-mono text-xs text-slate-400">{emp.cnic}</td>
                    <td className="table-cell">{emp.designation}</td>
                    <td className="table-cell">{emp.department}</td>
                    <td className="table-cell">{emp.office?.name || '—'}</td>
                    <td className="table-cell">
                      <span className={emp.employment_type === 'full-time' ? 'badge-green' : emp.employment_type === 'part-time' ? 'badge-yellow' : 'badge-blue'}>
                        {emp.employment_type}
                      </span>
                    </td>
                    <td className="table-cell">
                      <div className="flex gap-2">
                        <button
                          onClick={() => openEdit(emp)}
                          className="px-3 py-1.5 rounded-lg bg-ink-700 hover:bg-sky-500/20 text-slate-400 hover:text-sky-400 text-xs font-medium transition-all"
                        >Edit</button>
                        <button
                          onClick={() => setDeleteTarget(emp)}
                          className="px-3 py-1.5 rounded-lg bg-ink-700 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 text-xs font-medium transition-all"
                        >Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="px-4 py-3">
              <Pagination meta={meta} onPage={setPage} />
            </div>
          </div>
        )}
      </div>

      {/* Create / Edit Modal */}
      <Modal
        open={showForm}
        onClose={() => setShowForm(false)}
        title={editTarget ? 'Edit Employee' : 'Add Employee'}
        size="lg"
      >
        {formError && <Alert type="error" message={formError} className="mb-4" />}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField label="Full Name" required>
            <input className="input-field" placeholder="John Doe" {...F('name')} />
          </FormField>
          <FormField label="Email" required>
            <input type="email" className="input-field" placeholder="john@ngo.org" {...F('email')} />
          </FormField>
          <FormField label={editTarget ? 'New Password (leave blank to keep)' : 'Password'} required={!editTarget}>
            <input type="password" className="input-field" placeholder="••••••••" {...F('password')} />
          </FormField>
          <FormField label="Phone" required>
            <input className="input-field" placeholder="+92-300-0000000" {...F('phone')} />
          </FormField>
          <FormField label="CNIC" required>
            <input className="input-field" placeholder="00000-0000000-0" {...F('cnic')} />
          </FormField>
          <FormField label="Designation" required>
            <input className="input-field" placeholder="Field Officer" {...F('designation')} />
          </FormField>
          <FormField label="Department" required>
            <input className="input-field" placeholder="Operations" {...F('department')} />
          </FormField>
          <FormField label="Office" required>
            <select className="select-field" {...F('office_id')}>
              <option value="">Select office…</option>
              {offices.map((o) => (
                <option key={o.id} value={o.id}>{o.name}</option>
              ))}
            </select>
          </FormField>
          <FormField label="Employment Type">
            <select className="select-field" {...F('employment_type')}>
              <option value="full-time">Full-time</option>
              <option value="part-time">Part-time</option>
              <option value="contract">Contract</option>
            </select>
          </FormField>
          <FormField label="Date of Joining">
            <input type="date" className="input-field" {...F('date_of_joining')} />
          </FormField>
          <FormField label="Emergency Contact Name">
            <input className="input-field" placeholder="Jane Doe" {...F('emergency_contact_name')} />
          </FormField>
          <FormField label="Emergency Contact Phone">
            <input className="input-field" placeholder="+92-300-0000000" {...F('emergency_contact_phone')} />
          </FormField>
        </div>
        <div className="flex gap-3 justify-end mt-6">
          <button className="btn-ghost" onClick={() => setShowForm(false)} disabled={saving}>Cancel</button>
          <button className="btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? <Spinner size="sm" /> : editTarget ? 'Save Changes' : 'Create Employee'}
          </button>
        </div>
      </Modal>

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Employee"
        message={`Are you sure you want to delete ${deleteTarget?.user?.name || deleteTarget?.name}? This action cannot be undone.`}
      />
    </div>
  );
}

function FormField({ label, required, children }) {
  return (
    <div>
      <label className="block text-xs font-display font-semibold uppercase tracking-widest text-slate-500 mb-1.5">
        {label}{required && <span className="text-rose-400 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  );
}
