# NGO Management System — Frontend

A production-grade React dashboard for the NGO Management System Laravel backend.

---

## Tech Stack

- **React 18** + React Router v6
- **Tailwind CSS** (utility-first styling)
- **Axios** (API integration with interceptors)
- **Google Fonts**: Sora (display) + DM Sans (body) + JetBrains Mono

---

## Project Structure

```
src/
├── components/
│   ├── layout/
│   │   ├── DashboardLayout.jsx   # Main layout wrapper
│   │   ├── Sidebar.jsx           # Collapsible sidebar nav
│   │   └── Topbar.jsx            # Top navigation bar
│   └── ui/
│       └── index.jsx             # Reusable components (Modal, Alert, Spinner, etc.)
├── context/
│   └── AuthContext.jsx           # Auth state + login/logout logic
├── pages/
│   ├── LoginPage.jsx             # Login with API integration
│   ├── DashboardPage.jsx         # Stat cards + quick actions
│   ├── EmployeesPage.jsx         # CRUD employees
│   ├── OfficesPage.jsx           # Office management with geo-fence
│   ├── AttendancePage.jsx        # Check-in/out + logs
│   └── LeavesPage.jsx            # Apply/approve/reject leaves
├── services/
│   └── api.js                    # Axios instance + all API calls
├── App.jsx                       # Router setup
└── index.css                     # Tailwind + custom design system
```

---

## Setup & Run Locally

### Prerequisites
- Node.js 18+ 
- npm 9+
- Your Laravel backend running at `http://localhost:8000`

### 1. Install dependencies

```bash
cd ngo-frontend
npm install
```

### 2. Configure API URL

Edit `.env` (already created):
```
REACT_APP_API_URL=http://localhost:8000/api/v1
```

If your backend is on a different port or host, update this value.

### 3. Configure CORS on Laravel backend

In `config/cors.php`, make sure your frontend origin is allowed:
```php
'allowed_origins' => ['http://localhost:3000'],
```

Or during development, use `'allowed_origins' => ['*']`.

### 4. Start the development server

```bash
npm start
```

The app opens at **http://localhost:3000**

---

## Backend API Assumptions

| Assumption | Detail |
|---|---|
| Base URL | `http://localhost:8000/api/v1` |
| Auth | Laravel Sanctum Bearer token |
| Token storage | `localStorage` under key `ngo_token` |
| Pagination format | Laravel default: `{ data: [], meta: { current_page, last_page, total } }` |
| `GET /api/v1/dashboard` | Returns stats object with any of: `total_employees`, `employees_count`, `attendance_today`, `checked_in_today`, `total_offices`, `offices_count`, `pending_leaves`, `leaves_pending` |
| Employee create | Requires `name`, `email`, `password` (for user creation), `phone`, `cnic`, `designation`, `department`, `office_id` |
| Attendance check-in | Requires `latitude` + `longitude` (GPS coordinates) |
| Leave reject | Accepts optional `rejection_reason` in body |

---

## Deploying to Vercel

### Option A: Vercel CLI (recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Build first
npm run build

# Deploy
vercel --prod
```

When prompted:
- Framework: **Create React App**
- Build command: `npm run build`
- Output directory: `build`

Set environment variable in Vercel dashboard:
```
REACT_APP_API_URL = https://your-backend-url.com/api/v1
```

### Option B: Vercel via GitHub

1. Push this folder to a GitHub repo
2. Import on [vercel.com/new](https://vercel.com/new)
3. Set `REACT_APP_API_URL` in Environment Variables

> ⚠️ **Important**: Your Laravel backend must also be publicly accessible for the deployed frontend to work. Deploy it on Railway, Render, or a VPS and update CORS accordingly.

---

## Deploying to Netlify

```bash
npm run build

# Drag and drop the `build/` folder at app.netlify.com/drop
```

Create `public/_redirects`:
```
/*  /index.html  200
```

---

## Features by Module

### 🔐 Authentication
- Login form with validation and error display
- Token stored in localStorage, auto-attached to all requests
- 401 interceptor auto-redirects to login
- Persistent session via `GET /auth/me` on mount

### 📊 Dashboard
- Dynamic greeting based on time of day
- Stat cards: Employees, Attendance Today, Offices, Pending Leaves
- Quick action links
- User role/profile display

### 👥 Employees (Admin only)
- Paginated table with search
- Create employee (creates user + employee profile)
- Edit employee details
- Delete with confirmation
- Displays: name, CNIC, designation, department, office, employment type

### 🏢 Offices
- Card grid layout with geo-fence info
- Create/Edit/Delete (Super Admin only)
- Read-only view for other roles
- Displays: name, address, coordinates, radius, status

### 📋 Attendance
- Today's check-in/check-out card with live times
- GPS location capture via browser Geolocation API
- Manual coordinate entry fallback
- Log table with date/time/status filtering
- Status badges: present, late, half-day, pending

### 🌿 Leaves
- Apply for leave (all users)
- Admin can Approve / Reject with reason
- Users can Cancel pending leaves
- Filter by status
- Displays: employee, type, dates, days count, reason, status

---

## Role-Based Access

| Feature | Employee | HR Admin | Super Admin |
|---|---|---|---|
| Dashboard | ✓ | ✓ | ✓ |
| View Offices | ✓ | ✓ | ✓ |
| Manage Offices | ✗ | ✗ | ✓ |
| View Employees | ✗ | ✓ | ✓ |
| Manage Employees | ✗ | ✓ | ✓ |
| Own Attendance | ✓ | ✓ | ✓ |
| All Attendance | ✗ | ✓ | ✓ |
| Apply Leave | ✓ | ✓ | ✓ |
| Approve/Reject Leave | ✗ | ✓ | ✓ |
